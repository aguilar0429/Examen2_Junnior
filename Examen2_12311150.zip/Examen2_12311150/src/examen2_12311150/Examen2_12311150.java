/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examen2_12311150;
import java.util.Scanner;
import java.util.Random;
import javax.swing.JOptionPane;
/**
 *
 * @author Eduardo Aguilar
 */
public class Examen2_12311150 {
static int [][] MatrizOriginal;
static Random ran= new Random();
static int tamano;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Menu Principal=new Menu();
        Principal.setVisible(true);
        
        MatrizOriginal=new int [tamano][tamano];
        
    }
    public static void rellenarMatriz(){
        for(int i=0;i<MatrizOriginal.length;i++){
            for(int j=0;j<MatrizOriginal[0].length;j++){
                MatrizOriginal[i][j]=ran.nextInt();
            }
        }
        
      
    }
}
